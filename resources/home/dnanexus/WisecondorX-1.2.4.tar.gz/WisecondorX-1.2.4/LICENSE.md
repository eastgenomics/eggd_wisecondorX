Copyright (C) 2016 VU University Medical Center Amsterdam  
Author: Roy Straver (github.com/rstraver)  
Mod: Lennart Raman (github.com/leraman)  

WISECONDOR is distributed under the following license:  
[Attribution-NonCommercial-ShareAlike CC BY-NC-SA]( https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode)  
This license is governed by Dutch law and this license is subject to the exclusive jurisdiction of the courts of the Netherlands.
